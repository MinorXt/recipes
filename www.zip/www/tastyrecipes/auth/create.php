<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';

$name = $_POST['name'];
$path = "/tastyrecipes/uploads/" . $_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER["DOCUMENT_ROOT"] . $path);

$desc = $_POST['desc'];
$cooking_time = $_POST['cooking_time'];
$category = $_POST['category'];

$is_active = $_POST['is_active'];
$is_featured = $_POST['is_featured'];

if($is_active == "on"){
    $active = 1;
}else{
    $active = 0;
}
if($is_featured == "on"){
    $featured = 1;
}else{
    $featured = 0;
}

$pdo->query("INSERT INTO recipes (name, short_description, image, cooking_time, category_id, is_featured, is_active) VALUES ('$name', '$desc', '$path' , '$cooking_time' , '$category', '$featured', '$active')");
header("Location: /tastyrecipes/admin/index.php");

