<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';

$id = $_GET['id'];

$pdo->query("DELETE FROM recipes WHERE id = '$id'");

header('Location: /tastyrecipes/admin/index.php');