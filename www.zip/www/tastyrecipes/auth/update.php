<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';

$name = $_POST['name'];
$slug = $_POST['slug'];
$path = "/tastyrecipes/uploads/" . $_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER["DOCUMENT_ROOT"] . $path);

$short_description = $_POST['short_description'];
$recipe = $_POST['recipe'];
$rating = $_POST['rating'];
$cooking_time = $_POST['cooking_time'];
$is_active = $_POST['is_active'];
$is_featured = $_POST['is_featured'];
$id = $_POST['id'];
$category = $_POST['category'];

$pdo->query("UPDATE recipes SET name='$name', image='$path', short_description='$short_description', recipe='$recipe', rating='$rating', cooking_time='$cooking_time', is_active='$is_active', is_featured='$is_featured', category_id='$category'  where id='$id'");

header('Location: /tastyrecipes/admin/index.php');