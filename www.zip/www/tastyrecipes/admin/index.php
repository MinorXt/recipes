<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';
$select = $pdo->query("SELECT * FROM recipes");
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Список рецептов</h1>
<a href="/tastyrecipes/admin/crud/create.php">Добавить Рецепт</a>
<?php foreach ($select as $item):?>
    <p><?=$item['name']?></p>
    <a href="/tastyrecipes/admin/crud/update.php?id=<?=$item['id']?>">Редактировать</a>
    <a href="/tastyrecipes/auth/delete.php?id=<?=$item['id']?>">Удалить</a>
<?php endforeach;?>
</body>
</html>
