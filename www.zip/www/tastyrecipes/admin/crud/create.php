<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';

$cat = $pdo->query("SELECT * FROM categories");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Добавление</h1>
<form action="/tastyrecipes/auth/create.php" method="post" enctype="multipart/form-data">
    <input type="text" placeholder="название" name="name">
    <input type="file" placeholder="img" name="file">
    <input type="text" placeholder="описание" name="desc">
    <input type="text" placeholder="Время приготовления" name="cooking_time">
    <select name="category">
        <?php foreach ($cat as $item):?>
        <option value="<?=$item['id']?>"><?=$item['name']?></option>
        <?php endforeach;?>
    </select>
    <label for="checkbox">вывод на страницу</label>
    <input type="checkbox" name="is_featured" id="checkbox">

    <label for="checkbox">вывод на страницу</label>
    <input type="checkbox" name="is_active" id="checkbox">
    <input type="submit">
</form>
</body>
</html>
