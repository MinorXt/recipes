<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';

$id = $_GET['id'];
$all_info = $pdo->query("SELECT * FROM recipes WHERE id = '$id'");
$cat = $pdo->query("SELECT * FROM categories");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>редактирование</h1>
<form action="/tastyrecipes/auth/update.php" method="post" enctype="multipart/form-data">
   <?php foreach ($all_info as $item):?>
   <table>
       <thead>
            <tr>
                <td>Название</td>
                <td>Slug</td>
                <td>Фаил</td>
                <td>Описание</td>
                <td>Рецепт</td>
                <td>Рейтинг</td>
                <td>Время приготовления</td>
                <td>Вывод на странице</td>
                <td>Активный</td>
            </tr>
       </thead>
       <tbody>
            <tr>
               <td><input type="text" value="<?=$item['name']?>" name="name"></td>
               <td><input type="text" value="<?=$item['slug']?>" name="slug"></td>
               <td><input type="file" value="<?=$item['image']?>" name="file"></td>
               <td><input type="text" value="<?=$item['short_description']?>" name="short_description"></td>
               <td><input type="text" value="<?=$item['recipe']?>" name="recipe"></td>
               <td><input type="text" value="<?=$item['rating']?>" name="rating"></td>
               <td><input type="text" value="<?=$item['cooking_time']?>" name="cooking_time"></td>
                <td><input type="text" value="<?=$item['is_featured']?>" name="is_featured"></td>
               <td><input type="text" value="<?=$item['is_active']?>" name="is_active"></td>
               <td>

               </td>
               <td><input type="hidden" value="<?=$id?>" name="id"></td>
               <td><input type="submit"></td>
            </tr>
       </tbody>
   </table>
       <select name="category">
       <?php foreach ($cat as $item):?>
               <option value="<?=$item['id']?>"><?=$item['name']?></option>
       <?php endforeach;?>
       </select>
   <?php endforeach;?>
</form>
</body>
</html>